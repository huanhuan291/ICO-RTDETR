# ICO-RTDETR
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.8%2B-brightgreen)]()
[![PyTorch](https://img.shields.io/badge/PyTorch-1.13%2B-orange)]()

> 对应论文：[论文标题]（论文链接）| 作者 | 期刊 | 年份

## 简介

    ICO-RTDETR 针对荔枝成熟度数据集天然类别边界模糊以及类别样本分布不平衡的问题，引入类间有序模块，提升了荔枝成熟度检测分类的准确度，同时代码保持原始 RT-DETR 的实时端到端优势，无需 NMS 后处理。准确度与实时性的兼顾，为荔枝采摘提供更加精确可靠的技术支持。

## 特性

- 类间有序模块：专门针对荔枝成熟度分类中存在的类别边界模糊以及类别样本分布不平衡问题设计。
- 精准成熟度识别：专为荔枝成熟度检测任务优化，输出结果直接服务于自动化采摘决策。
- 端到端检测架构：保持原始RT-DETR的简洁架构，无需NMS后处理。

## 安装环境

- python 3.8
- torch 2.3.1+cu126
- torchaudio 2.0.2+cu126
- torchvision 0.15.2+cu126
- timm 0.9.8
- mmcv 2.0.1
- mmengine 0.9.0
